import subprocess
from celery import Celery, shared_task
import os


from celery import shared_task
from app.core.config import settings

celery_app = Celery(__name__)
celery_app.conf.broker_url = settings.REDIS_URL

@shared_task
def crack_rar_password(archive_path: str) -> str:
    base_dir = r"C:\Users\nikpe\john\run"
    rar2john_path = os.path.join(base_dir, "rar2john.exe")
    john_path = os.path.join(base_dir, "john.exe")
    hash_file = os.path.join(base_dir, "temp.hash")
    wordlist_path = os.path.join(base_dir, "rockyou.txt")

    logger.info(f"Архив: {archive_path}")
    logger.info("Генерация хэша...")

    try:
        result = subprocess.run(
            [rar2john_path, archive_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )
        with open(hash_file, "w", encoding="utf-8") as f:
            f.write(result.stdout.decode("utf-8"))

        logger.info(" Хэш успешно создан.")
    except Exception as e:
        logger.error(f" Ошибка при создании хеша: {str(e)}")
        return f" Ошибка при создании хеша: {str(e)}"

    logger.info(" Запуск John the Ripper...")

    try:
        subprocess.run(
            [john_path, hash_file, f"--wordlist={wordlist_path}"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )
        logger.info(" John успешно отработал.")
    except Exception as e:
        logger.error(f" Ошибка при запуске John: {str(e)}")
        return f" Ошибка при запуске John the Ripper: {str(e)}"

    logger.info(" Получение результата...")

    try:
        show_result = subprocess.run(
            [john_path, hash_file, "--show"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            check=True
        )
        output = show_result.stdout.decode("utf-8")
        logger.info(f" Результат: {output}")
        return output
    except Exception as e:
        logger.error(f" Ошибка при получении результата: {str(e)}")
        return f" Ошибка при получении результата: {str(e)}"
