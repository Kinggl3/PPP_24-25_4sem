
from celery import Celery

celery_app = Celery(
    "PrP2",
    broker="redis://localhost:6380/0",
    backend="redis://localhost:6380/0"
)

celery_app.autodiscover_tasks(["app.services"])