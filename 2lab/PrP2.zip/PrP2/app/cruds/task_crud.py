from sqlalchemy.orm import Session
from typing import Optional
from app.models.task_model import Task, TaskStatus


def add_new_task(db: Session, hash_value: str, charset: str, max_length: int) -> Task:
    new_task = Task(
        hash_value=hash_value,
        charset=charset,
        max_length=max_length,
        status=TaskStatus.pending
    )
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    return new_task


def get_task(db: Session, task_id: int) -> Optional[Task]:
    return db.query(Task).filter(Task.id == task_id).first()


def update_task_progress(
    db: Session,
    task_id: int,
    status: TaskStatus,
    result: Optional[str] = None,
    progress: Optional[float] = None
) -> Optional[Task]:
    task = db.query(Task).filter(Task.id == task_id).first()
    if task:
        task.status = status
        if result is not None:
            task.result = result
        if progress is not None:
            task.progress = progress
        db.commit()
        db.refresh(task)
    return task

