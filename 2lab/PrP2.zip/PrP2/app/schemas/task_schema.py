from pydantic import BaseModel
from typing import Optional


class TaskCreate(BaseModel):
    hash_value: str
    charset: str
    max_length: int


class TaskInfo(BaseModel):
    id: int
    status: str
    progress: float
    result: Optional[str] = None

    class Config:
        from_attributes = True
