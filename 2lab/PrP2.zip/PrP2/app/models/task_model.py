from sqlalchemy import Column, Integer, String, Float, Enum
from app.db.session import Base
import enum


class TaskStatus(str, enum.Enum):
    pending = "pending"
    in_progress = "in_progress"
    success = "success"
    failed = "failed"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, index=True)

    hash_value = Column(String, nullable=False)
    charset = Column(String, nullable=False)
    max_length = Column(Integer, nullable=False)
    status = Column(Enum(TaskStatus), default=TaskStatus.pending)
    progress = Column(Float, default=0.0)
    result = Column(String, nullable=True)
