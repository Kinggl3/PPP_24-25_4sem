
from app.services.task_service import crack_rar_password


from fastapi import APIRouter, Query, HTTPException
from celery.result import AsyncResult


from celery.exceptions import CeleryError

router = APIRouter()


@router.post("/crack")
def start_crack_task(archive_path: str = Query(...)):
    try:
        task = crack_rar_password.delay(archive_path)
    except CeleryError as e:
        raise HTTPException(status_code=503, detail=f"Celery error: {str(e)}")

    return {
        "task_id": task.id,
        "status": "started"
    }


@router.get("/{task_id}")
def get_task_status(task_id: str):
    result = AsyncResult(task_id)
    return {
        "task_id": task_id,
        "status": result.status,
        "result": str(result.result) if result.successful() else None
    }

