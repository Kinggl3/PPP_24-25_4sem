import requests
import websockets
import asyncio
import json
import os

API_URL = "http://127.0.0.1:8000"
WS_URL = "ws://127.0.0.1:8000/ws?token={token}"

def login_user(email, password):
    r = requests.post(f"{API_URL}/login/", data={"username": email, "password": password})
    r.raise_for_status()
    return r.json()["access_token"]

def upload_rar(token, rar_path):
    headers = {"Authorization": f"Bearer {token}"}
    with open(rar_path, "rb") as f:
        files = {"file": (os.path.basename(rar_path), f, "application/x-rar-compressed")}
        r = requests.post(f"{API_URL}/upload_rar", files=files, headers=headers)
        r.raise_for_status()
        return r.json()["task_id"]

async def listen_ws(token, task_id):
    async with websockets.connect(WS_URL.format(token=token)) as ws:
        await ws.send(task_id)
        while True:
            msg = await ws.recv()
            data = json.loads(msg)
            print("[WS] →", json.dumps(data, indent=2, ensure_ascii=False))

            if data.get("status") in {"completed", "failed", "cancelled"}:
                break

def main():
    email = input("Введите email: ")
    password = input("Введите пароль: ")
    rar_path = input("Введите путь к .rar архиву: ")

    token = login_user(email, password)
    print("[+] Успешный вход. JWT токен:", token)

    task_id = upload_rar(token, rar_path)
    print("[*] Загружен архив. Task ID:", task_id)

    asyncio.run(listen_ws(token, task_id))

    while True:
        cmd = input("Введите команду (/pause [task_id], /resume [task_id], /cancel [task_id], /exit): ")

        if cmd.startswith("/pause "):
            tid = cmd.split()[1]
            requests.post(f"{API_URL}/task/control", params={"task_id": tid, "action": "pause"})
        elif cmd.startswith("/resume "):
            tid = cmd.split()[1]
            requests.post(f"{API_URL}/task/control", params={"task_id": tid, "action": "resume"})
        elif cmd.startswith("/cancel "):
            tid = cmd.split()[1]
            requests.post(f"{API_URL}/task/control", params={"task_id": tid, "action": "cancel"})
        elif cmd == "/exit":
            break
        else:
            print("Неизвестная команда")

if __name__ == "__main__":
    main()