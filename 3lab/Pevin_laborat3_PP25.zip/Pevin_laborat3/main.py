import asyncio
from fastapi import WebSocket, WebSocketDisconnect
from app.core.config import create_app
from app.api.end_point import router
from app.services.websocket_manager import manager
from app.services.state import get_task_status
from app.core.security import SECRET_KEY, ALGORITHM
from jose import jwt, JWTError
from fastapi.openapi.utils import get_openapi

app = create_app()
app.include_router(router)

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    token = websocket.query_params.get("token")
    task_id = websocket.query_params.get("task_id")

    if not token:
        await websocket.close(code=1008)
        return

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        user_id = str(payload.get("sub"))
        if not user_id:
            await websocket.close(code=1008)
            return
    except JWTError:
        await websocket.close(code=1008)
        return

    await manager.connect(user_id, websocket)

    try:
        if not task_id:
            task_id = await websocket.receive_text()

        last_status = None

        while True:
            status = get_task_status(task_id)

            if status != last_status:
                await manager.send_status(user_id, status)
                last_status = status

            if status["status"] in ["completed", "failed"]:
                break

            await asyncio.sleep(1)

    except WebSocketDisconnect:
        await manager.disconnect(user_id)
    except Exception as e:
        print("WebSocket error:", e)
        await manager.disconnect(user_id)

def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title="Bruteforce API",
        version="1.0.0",
        description="API for RAR password bruteforcing",
        routes=app.routes,
    )

    if "components" in openapi_schema:
        schemes = openapi_schema["components"].get("securitySchemes", {})
        for scheme in schemes.values():
            if "flows" in scheme and "password" in scheme["flows"]:
                scheme["flows"]["password"].pop("scopes", None)
                scheme["flows"]["password"].pop("refreshUrl", None)
                scheme["flows"]["password"].pop("client_id", None)
                scheme["flows"]["password"].pop("client_secret", None)

    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
