from redislite import Redis

r = Redis('/home/nikpe/brutforce_project/db/redis.db')

def set_task_status(task_id: str, status: str, progress: int = 0, result: str = None):
    r.hmset(f"task:{task_id}", {
        "status": status,
        "progress": progress,
        "result": result or ""
    })

def get_task_status(task_id: str):
    data = r.hgetall(f"task:{task_id}")
    if not data:
        return {"status": "not_found", "progress": 0, "result": None}
    return {
        "status": data[b"status"].decode(),
        "progress": int(data[b"progress"]),
        "result": data[b"result"].decode() or None
    }

def set_control_flag(task_id: str, flag: str):
    r.hset(f"task:{task_id}", "control", flag)

def get_control_flag(task_id: str) -> str:
    return r.hget(f"task:{task_id}", "control").decode("utf-8") if r.hexists(f"task:{task_id}", "control") else "running"

