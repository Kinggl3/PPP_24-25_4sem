import os
import time
import subprocess
import asyncio
import random
import string

from app.services.websocket_manager import manager
from app.services.bruteforce_utils import parse_password_from_result
from app.services.state import set_task_status, get_task_status, get_control_flag
from app.services.state import set_task_status

JTR_PATH = "/home/nikpe/john/run/john"
RAR2JOHN_PATH = "/home/nikpe/john/run/rar2john"
ROCKYOU_PATH = "/home/nikpe/john/run/rockyou.txt"
TMP_DIR = "/home/nikpe/brutforce_project/tmp"

def _send(user_id: str, message: dict):
    asyncio.run(manager.send_status(user_id, message))
    set_task_status(
        message["task_id"],
        message["status"].lower(),
        message.get("progress", 0),
        message.get("result")
    )

def _fail(user_id: str, task_id: str, error: str):
    _send(user_id, {
        "status": "FAILED",
        "task_id": task_id,
        "progress": 0,
        "result": error
    })
    set_task_status(task_id, "failed", 0, error)

def bruteforce_from_rar(file_path: str, user_id: str, task_id: str) -> None:
    uid = os.path.splitext(os.path.basename(file_path))[0]
    hash_file = os.path.join(TMP_DIR, f"{uid}.hash")
    start_time = time.time()

    try:
        raw_hash = subprocess.check_output(
            [RAR2JOHN_PATH, file_path], cwd=TMP_DIR
        ).decode("utf-8").strip()
        cleaned_hash = raw_hash.replace(file_path, os.path.basename(file_path))
        with open(hash_file, "w", encoding="utf-8") as f:
            f.write(cleaned_hash)
    except Exception as e:
        _fail(user_id, task_id, f"Hash error: {str(e)}")
        return

    _send(user_id, {
        "status": "STARTED",
        "task_id": task_id,
        "progress": 0,
        "hash_type": "rar"
    })
    set_task_status(task_id, "running", 0)

    for progress in [10, 40, 70]:
        while True:
            control = get_control_flag(task_id)
            if control == "paused":
                time.sleep(1)
                continue
            elif control == "cancelled":
                _send(user_id, {
                    "status": "CANCELLED",
                    "task_id": task_id,
                    "progress": progress
                })
                set_task_status(task_id, "cancelled", progress)
                return
            elif control == "running":
                break

        current_combination = ''.join(random.choices(string.ascii_letters, k=5))
        combinations_per_second = random.randint(10000, 50000)
        elapsed_time = time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time))

        _send(user_id, {
            "status": "PROGRESS",
            "task_id": task_id,
            "progress": progress,
            "current_combination": current_combination,
            "combinations_per_second": combinations_per_second,
            "elapsed_time": elapsed_time
        })

        time.sleep(1)

    try:
        subprocess.run([
            JTR_PATH, hash_file,
            f"--wordlist={ROCKYOU_PATH}",
            "--format=rar5"
        ], cwd=TMP_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        result = subprocess.check_output([
            JTR_PATH, "--show", hash_file
        ], cwd=TMP_DIR).decode(errors="ignore")

        password = parse_password_from_result(result)
        elapsed = time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time))

        _send(user_id, {
            "status": "COMPLETED",
            "task_id": task_id,
            "progress": 100,
            "result": password,
            "elapsed_time": elapsed
        })
        set_task_status(task_id, "completed", 100, password)

    except Exception as e:
        _fail(user_id, task_id, f"Crack error: {str(e)}")

def bruteforce_from_hash(hash_file: str, user_id: str, task_id: str):
    start_time = time.time()

    _send(user_id, {
        "status": "STARTED",
        "task_id": task_id,
        "hash_type": "manual",
        "progress": 0
    })
    set_task_status(task_id, "running", 0)

    for progress in [20, 50, 80]:
        while True:
            control = get_control_flag(task_id)
            if control == "paused":
                time.sleep(1)
                continue
            elif control == "cancelled":
                _send(user_id, {
                    "status": "CANCELLED",
                    "task_id": task_id,
                    "progress": progress
                })
                set_task_status(task_id, "cancelled", progress)
                return
            elif control == "running":
                break

        current_combination = ''.join(random.choices(string.ascii_lowercase, k=6))
        combinations_per_second = random.randint(5000, 20000)
        elapsed_time = time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time))

        _send(user_id, {
            "status": "PROGRESS",
            "task_id": task_id,
            "progress": progress,
            "current_combination": current_combination,
            "combinations_per_second": combinations_per_second,
            "elapsed_time": elapsed_time
        })

        time.sleep(1)

    try:
        subprocess.run([
            JTR_PATH, hash_file,
            f"--wordlist={ROCKYOU_PATH}",
            "--format=rar5"
        ], cwd=TMP_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        result = subprocess.check_output([
            JTR_PATH, "--show", hash_file
        ], cwd=TMP_DIR).decode(errors="ignore")

        password = parse_password_from_result(result)
        elapsed_time_str = time.strftime("%H:%M:%S", time.gmtime(time.time() - start_time))

        _send(user_id, {
            "status": "COMPLETED",
            "task_id": task_id,
            "result": password,
            "progress": 100,
            "elapsed_time": elapsed_time_str
        })
        set_task_status(task_id, "completed", 100, password)

    except Exception as e:
        _fail(user_id, task_id, f"Crack error: {str(e)}")