from typing import Dict, List
from fastapi import WebSocket
import asyncio

class WebSocketManager:
    def __init__(self):
        self.active_connections: Dict[str, List[WebSocket]] = {}

    async def connect(self, user_id: str, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.setdefault(user_id, []).append(websocket)

    async def disconnect(self, user_id: str, websocket: WebSocket):
        if user_id in self.active_connections:
            self.active_connections[user_id].remove(websocket)
            if not self.active_connections[user_id]:
                del self.active_connections[user_id]

    async def send_status(self, user_id: str, message: dict):
        connections = self.active_connections.get(user_id, [])
        for ws in connections:
            try:
                await ws.send_json(message)
            except Exception:
                pass
from app.services.state import get_task_status

async def monitor_task(user_id: str, task_id: str):
    prev_status = None
    while True:
        status = get_task_status(task_id)
        if status is None:
            await asyncio.sleep(1)
            continue

        if status["status"] != prev_status:
            await manager.send_status(user_id, {
                "task_id": task_id,
                "status": status["status"],
                "progress": status.get("progress", 0),
                "result": status.get("result"),
            })
            prev_status = status["status"]

        if status["status"] in {"completed", "failed"}:
            break

        await asyncio.sleep(1)

manager = WebSocketManager()
