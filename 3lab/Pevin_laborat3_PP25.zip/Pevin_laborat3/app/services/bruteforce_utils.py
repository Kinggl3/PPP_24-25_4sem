def parse_password_from_result(result: str) -> str:
    if ":" not in result:
        return "Не найден"
    return result.split(":", 1)[1].strip().split("\n")[0]
