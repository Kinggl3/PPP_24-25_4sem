from pydantic import BaseModel, EmailStr

class UserCreate(BaseModel):
    email: EmailStr
    password: str

class TokenResponse(BaseModel):
    id: int
    email: EmailStr
    token: str

class OAuth2Token(BaseModel):
    access_token: str
    token_type: str

class UserRead(BaseModel):
    id: int
    email: EmailStr

    class Config:
        from_attributes = True

