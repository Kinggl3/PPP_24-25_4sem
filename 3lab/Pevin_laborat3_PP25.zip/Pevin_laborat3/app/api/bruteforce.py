from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from app.schemas.bruteforce import BrutRequest, BrutResponse
from celery_worker import run_bruteforce, run_bruteforce_hash
from app.core.security import get_current_user
from app.models.user import User
from app.services.state import get_task_status, set_control_flag
import uuid
import os

router = APIRouter()

@router.post("/brut_hash", response_model=BrutResponse)
def brut_hash(request: BrutRequest, user: User = Depends(get_current_user)):
    uid = str(uuid.uuid4())
    hash_path = os.path.join("/home/nikpe/john/run", f"{uid}.hash")

    with open(hash_path, "w", encoding="utf-8") as f:
        f.write(request.hash.strip())

    task_id = str(uuid.uuid4())
    run_bruteforce_hash.delay(hash_path, str(user.id), task_id)
    return {"task_id": task_id}

@router.get("/get_status")
def get_status(task_id: str):
    return get_task_status(task_id)

@router.post("/task/control")
def control_task(task_id: str, action: str):
    if action not in {"pause", "resume", "cancel"}:
        raise HTTPException(status_code=400, detail="Invalid action")
    flag = {"pause": "paused", "resume": "running", "cancel": "cancelled"}[action]
    set_control_flag(task_id, flag)
    return {"task_id": task_id, "control": flag}

@router.get("/get_status")
def get_status(task_id: str):
    return get_task_status(task_id)
