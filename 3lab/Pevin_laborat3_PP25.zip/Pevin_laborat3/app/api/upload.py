from fastapi import APIRouter, UploadFile, File, Depends
from app.schemas.upload import UploadResponse
from celery_worker import run_bruteforce
from app.core.security import get_current_user
from app.models.user import User
from app.services.bruteforce import TMP_DIR
from app.services.websocket_manager import manager, monitor_task

import os
import uuid
import asyncio

router = APIRouter()

@router.post("/upload_rar", response_model=UploadResponse)
async def upload_rar(file: UploadFile = File(...), user: User = Depends(get_current_user)):
    rar_path = os.path.join(TMP_DIR, file.filename)
    with open(rar_path, "wb") as f:
        f.write(file.file.read())

    task_id = str(uuid.uuid4())

    await manager.send_status(str(user.id), {
        "status": "RECEIVED",
        "task_id": task_id,
        "progress": 0
    })

    asyncio.create_task(monitor_task(str(user.id), task_id))

    run_bruteforce.delay(rar_path, str(user.id), task_id)

    return {"task_id": task_id}

