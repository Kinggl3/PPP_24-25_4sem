from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from fastapi.security import OAuth2PasswordRequestForm
from app.schemas.user import UserCreate, TokenResponse, OAuth2Token
from app.cruds.user import get_user_by_email, create_user
from app.services.auth import verify_password, create_access_token
from app.db.dependency import get_db
from app.core.security import get_current_user
from app.models.user import User



router = APIRouter()

@router.post("/sign-up/", response_model=TokenResponse)
def register(user: UserCreate, db: Session = Depends(get_db)):
    existing_user = get_user_by_email(db, user.email)
    if existing_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    new_user = create_user(db, user)
    token = create_access_token({"sub": str(new_user.id)})
    return {"id": new_user.id, "email": new_user.email, "token": token}

@router.post("/login/", response_model=OAuth2Token, include_in_schema=False)
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    db_user = get_user_by_email(db, form_data.username)
    if not db_user or not verify_password(form_data.password, db_user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_access_token({"sub": str(db_user.id)})
    return {"access_token": token, "token_type": "bearer"}

@router.get("/users/me/", response_model=TokenResponse)
def get_me(current_user: User = Depends(get_current_user)):
    token = create_access_token({"sub": str(current_user.id)})
    return {
        "id": current_user.id,
        "email": current_user.email,
        "token": token
    }
