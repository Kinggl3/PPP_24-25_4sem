from celery import Celery
from app.services.bruteforce import bruteforce_from_rar, bruteforce_from_hash


app = Celery(
    "tasks",
    broker="redis+socket:///tmp/tmp2z0td48e/redis.socket",
    backend="redis+socket:///tmp/tmp2z0td48e/redis.socket"
)

@app.task
def run_bruteforce(file_path: str, user_id: str, task_id: str):
    bruteforce_from_rar(file_path, user_id, task_id)

@app.task
def run_bruteforce_hash(hash_path: str, user_id: str, task_id: str):
    bruteforce_from_hash(hash_path, user_id, task_id)
